package com.raven.event;

import com.raven.model.ModelItem;
import java.awt.Component;

public interface EventItem {
    void itemClick(Component com, ModelItem item);
    void itemButtonClick(ModelItem item); // Tambahkan metode baru
}
